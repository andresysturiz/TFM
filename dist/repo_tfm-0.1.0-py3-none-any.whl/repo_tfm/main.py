# main.py

import pandas as pd

from src.repo_tfm.scripts.core.logger import get_logger
from src.repo_tfm.scripts.core.utils import safe_create_dir
from src.repo_tfm.scripts.core.eda import DatasetAnalyzer
from src.repo_tfm.scripts.core.data_loader import DataLoader
from src.repo_tfm.scripts.experiments.pls_experiment import PLSExperiment
from src.repo_tfm.scripts.experiments.pls_final_experiment import PLSFinalExperiment
from src.repo_tfm.scripts.experiments.classical_experiment import ClassicalExperiment
from src.repo_tfm.scripts.experiments.classification_experiment import ClassificationExperiment
from src.repo_tfm.scripts.compare_runner import compare_results

logger = get_logger("MainPipeline")


def run_pipeline_for_dataset(dataset):
    logger.info(f"=== Procesando dataset: {dataset} ===")

    # ============================
    # CARGA DEL DATASET
    # ============================
    loaded = DataLoader().load(dataset)

    # ============================
    # CLASIFICACIÓN (GOLUB)
    # ============================
    if dataset == "golub":
        expr_df, labels = loaded

        # Crear DataFrame para EDA
        df = expr_df.T.copy()
        df["class"] = labels.values

        # EDA opcional (si no quieres 3000 boxplots, déjalo comentado)
        # DatasetAnalyzer().analyze(df, dataset_name=dataset, target="class")

        logger.info("Ejecutando ClassificationExperiment")
        ClassificationExperiment(dataset=dataset).run()

        logger.info("Comparando resultados para Golub")
        compare_results(dataset)
        return

    # ============================
    # REGRESIÓN (WINE, GASOLINE)
    # ============================
    df, X, y = loaded
    target_col = df.columns[-1]

    # EDA
    # DatasetAnalyzer().analyze(df, dataset_name=dataset, target=target_col)

    # 1. PLS CV
    logger.info(f"Ejecutando PLSExperiment (CV) para {dataset}")
    PLSExperiment(dataset=dataset).run()

    # Leer mejor número de componentes
    pls_cv_path = f"results/{dataset}/csv/pls_cv_{dataset}.csv"
    pls_cv_df = pd.read_csv(pls_cv_path)
    best_components = int(pls_cv_df.loc[pls_cv_df["rmse_cv"].idxmin(), "n_components"])

    # 2. PLS FINAL
    logger.info(f"Entrenando PLS FINAL para {dataset}")
    PLSFinalExperiment(dataset=dataset, best_components=best_components).run()

    # 3. Modelos clásicos
    logger.info(f"Ejecutando ClassicalExperiment para {dataset}")
    ClassicalExperiment(dataset=dataset).run()

    # 4. Comparación final
    logger.info(f"Comparando resultados para {dataset}")
    compare_results(dataset)

    logger.info(f"=== Dataset {dataset} procesado correctamente ===")


def main():
    logger.info("=== INICIANDO PIPELINE COMPLETO ===")

    safe_create_dir("results")

    datasets = ["wine", "gasoline", "golub"]

    for dataset in datasets:
        run_pipeline_for_dataset(dataset)

    logger.info("=== PIPELINE COMPLETO FINALIZADO ===")


if __name__ == "__main__":
    main()
