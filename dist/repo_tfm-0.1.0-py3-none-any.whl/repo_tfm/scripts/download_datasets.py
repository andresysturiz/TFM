# scripts/download_datasets.py

import ssl
import os
import pandas as pd
import requests
from ucimlrepo import fetch_ucirepo
import subprocess
import shutil
from pathlib import Path

from src.repo_tfm.scripts.core.logger import get_logger
from src.repo_tfm.scripts.core.errors import DownloadError
from src.repo_tfm.scripts.core.utils import safe_create_dir

logger = get_logger("download")

# Desactivar SSL solo dentro de este script
ssl._create_default_https_context = ssl._create_unverified_context


# ============================================================
# DESCARGA DESDE UCI
# ============================================================

def download_dataset(id, name, filename):
    try:
        logger.info(f"Descargando {name} (UCI)...")
        data = fetch_ucirepo(id=id)

        df = pd.concat([data.data.features, data.data.targets], axis=1)

        if df.empty:
            raise DownloadError(f"{name} está vacío")

        df.to_csv(filename, index=False)
        logger.info(f"{name} guardado en {filename} ({df.shape[0]} filas, {df.shape[1]} columnas)")

    except Exception as e:
        logger.error(f"Error descargando {name}: {str(e)}")
        if os.path.exists(filename):
            os.remove(filename)
        raise DownloadError(f"No se pudo descargar {name}")


# ============================================================
# GASOLINE (dataset real NIR)
# ============================================================

def download_gasoline():
    print("Descargando Gasoline usando R (CRAN)...")

    r_script = Path("R/export_gasoline.R")
    output_csv = Path("gasoline.csv")
    target_csv = Path("data/raw/gasoline.csv")

    try:
        # Ejecutar Rscript
        subprocess.run(
            ["Rscript", str(r_script)],
            check=True
        )

        # Mover el CSV generado
        shutil.move(str(output_csv), str(target_csv))

        print("Gasoline descargado correctamente desde R (CRAN).")

    except Exception as e:
        raise DownloadError(f"Error ejecutando R para descargar Gasoline: {e}")


# ============================================================
# GOLUB (gene expression)
# ============================================================

def download_golub():
    print("Descargando Golub usando R (Bioconductor)...")

    r_script = Path("R/export_golub.R")
    expr_csv = Path("golub_expression.csv")
    labels_csv = Path("golub_labels.csv")

    target_expr = Path("data/raw/golub_expression.csv")
    target_labels = Path("data/raw/golub_labels.csv")

    try:
        subprocess.run(["Rscript", str(r_script)], check=True)

        shutil.move(str(expr_csv), str(target_expr))
        shutil.move(str(labels_csv), str(target_labels))

        print("Golub descargado correctamente desde R (Bioconductor).")

    except Exception as e:
        raise DownloadError(f"Error ejecutando R para descargar Golub: {e}")



# ============================================================
# MAIN
# ============================================================

def main():
    safe_create_dir("data/raw")

    # UCI datasets
    download_dataset(186, "Wine Quality", "data/raw/wine_quality.csv")

    # Nuevos datasets
    download_gasoline()
    download_golub()

    logger.info("Descarga completada correctamente.")


if __name__ == "__main__":
    main()
