# scripts/core/data_loader.py

import pandas as pd
from src.repo_tfm.scripts.core.utils import safe_read_csv
from src.repo_tfm.scripts.core.logger import get_logger

logger = get_logger("DataLoader")


class DataLoader:
    """
    Clase para cargar datasets por nombre.
    Devuelve (df, X, y) para regresión.
    Devuelve (expr_df, labels_df) para Golub (clasificación).
    """

    def __init__(self, base_path="data/raw"):
        self.base_path = base_path

    # -------------------------
    # MÉTODO PRINCIPAL
    # -------------------------
    def load(self, name):
        name = name.lower()

        if name == "wine":
            return self._load_wine()

        if name == "gasoline":
            return self._load_gasoline()

        if name == "golub":
            return self._load_golub()

        raise ValueError(f"Dataset '{name}' no está soportado.")

    # -------------------------
    # WINE QUALITY
    # -------------------------
    def _load_wine(self):
        path = f"{self.base_path}/wine_quality.csv"
        df = safe_read_csv(path)

        X = df.drop(columns=["quality"]).values
        y = df["quality"].values

        logger.info(f"Wine cargado: {df.shape[0]} filas, {df.shape[1]} columnas")
        return df, X, y

    # -------------------------
    # GASOLINE (regresión)
    # -------------------------
    def _load_gasoline(self):
        path = f"{self.base_path}/gasoline.csv"
        df = safe_read_csv(path)

        if "octane" not in df.columns:
            raise ValueError("El dataset Gasoline no contiene la columna 'octane'.")

        X = df.drop(columns=["octane"]).values
        y = df["octane"].values

        logger.info(f"Gasoline cargado: {df.shape[0]} filas, {df.shape[1]} columnas")
        return df, X, y

    # -------------------------
    # GOLUB (clasificación)
    # -------------------------
    def _load_golub(self):
        expr_path = f"{self.base_path}/golub_expression.csv"
        labels_path = f"{self.base_path}/golub_labels.csv"

        expr = safe_read_csv(expr_path)
        labels = safe_read_csv(labels_path)

        # Aceptar varias posibles columnas de clase
        if "class" in labels.columns:
            y = labels["class"]
        elif "x" in labels.columns:
            y = labels["x"]
        elif labels.shape[1] == 1:
            # Columna única sin nombre estándar
            y = labels.iloc[:, 0]
        else:
            raise ValueError(f"No se encontró columna válida de etiquetas en Golub: {labels.columns}")


        logger.info(f"Golub cargado: expr={expr.shape}, labels={labels.shape}")
        return expr, y

