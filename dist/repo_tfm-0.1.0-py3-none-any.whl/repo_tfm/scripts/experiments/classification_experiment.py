import os
import time
import pandas as pd
from sklearn.svm import LinearSVC
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

from src.repo_tfm.scripts.core.base_experiment import BaseExperiment
from src.repo_tfm.scripts.core.logger import get_logger
from src.repo_tfm.scripts.core.utils import safe_create_dir
from src.repo_tfm.scripts.models.pls_model import PLSModel   # <-- IMPORTANTE

logger = get_logger("ClassificationExperiment")


class ClassificationExperiment(BaseExperiment):
    """
    Modelos lineales de clasificación:
    - Logistic Regression
    - Logistic Regression L1
    - Linear SVM
    - PLS-DA (via PLSModel con selección automática)
    """

    def __init__(self, dataset):
        super().__init__(name="Classification", dataset=dataset)

    def run(self):
        logger.info(f"Iniciando modelos lineales de clasificación para dataset: {self.dataset}")

        # 1. Preparar datos
        self.prepare_data()

        X_train = self.X_train
        X_test = self.X_test
        y_train = self.y_train
        y_test = self.y_test

        base_dir = f"results/{self.dataset}/csv"
        safe_create_dir(base_dir)

        results = []

        # ============================================================
        # 1. Logistic Regression
        # ============================================================
        model = LogisticRegression(max_iter=5000)
        results.append(self._train_eval(model, "LogisticRegression",
                                        X_train, X_test, y_train, y_test))

        # ============================================================
        # 2. Logistic Regression L1
        # ============================================================
        model = LogisticRegression(max_iter=5000, penalty="l1", solver="liblinear")
        results.append(self._train_eval(model, "LogisticRegression_L1",
                                        X_train, X_test, y_train, y_test))

        # ============================================================
        # 3. Linear SVM
        # ============================================================
        model = LinearSVC()
        results.append(self._train_eval(model, "LinearSVM",
                                        X_train, X_test, y_train, y_test))

        # ============================================================
        # 4. PLS-DA (automático)
        # ============================================================
        pls = PLSModel()   # <-- auto selección + clasificación automática
        results.append(self._train_eval(pls, "PLS_DA",
                                        X_train, X_test, y_train, y_test))

        # ============================================================
        # GUARDAR RESULTADOS
        # ============================================================
        df = pd.DataFrame(results)
        out_path = f"{base_dir}/classical_results_{self.dataset}.csv"
        df.to_csv(out_path, index=False)

        logger.info(f"Resultados de clasificación guardados en {out_path}")

    # ============================================================
    # MÉTODO AUXILIAR
    # ============================================================

    def _train_eval(self, model, name, X_train, X_test, y_train, y_test):
        logger.info(f"Entrenando modelo: {name}")

        start = time.time()
        model.fit(X_train, y_train)
        end = time.time()

        pred = model.predict(X_test)

        # Probabilidades si existen
        if hasattr(model, "predict_proba"):
            probas = model.predict_proba(X_test)[:, 1]
        else:
            probas = pred  # fallback para LinearSVM

        return {
            "model": name,
            "accuracy": accuracy_score(y_test, pred),
            "f1": f1_score(y_test, pred),
            "roc_auc": roc_auc_score(y_test, probas),
            "train_time": end - start,
            "best_components": getattr(model, "best_components_", None)
        }
